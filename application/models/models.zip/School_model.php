<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class School_model extends CI_Model {
    public $_hrm_dbname     =   '_hrm';
    public $_fi_dbname     =   '_fi';
    
    public function __construct() {
        parent::__construct();
    }
    private $_table = "schools";
    
    function get_instance_name()
    {
        $url_arr=explode('/', $_SERVER['PHP_SELF']);
        $dir=$url_arr[1];
        return $dir;
    }
    
    public function save_school($data,$edata) {
        $this->db->insert('schools', $data);
        $ins = $this->db->insert_id();
        
        // Save Business Unit in HRM
        $buData = array(
            'unitname' => $data['name'],
            'unitcode' => $ins,
            'description' => $data['name'],
            'address1' => $data['addr_line1'],
            'address2' => $data['addr_line2'],
            'service_desk_flag' => '1',
            'isactive' => '1',
            'school_id' => $ins
        ); 
        
        $instance = $this->get_instance_name();
        $this->db->db_select($instance.$this->_hrm_dbname);
        $this->db->insert('main_businessunits', $buData); 
        $ins1 = $this->db->insert_id();
        
        // Save Employee in HRM
        $empData = array(
            'emprole' => '2',
            'userstatus' => 'old',
            'firstname' => $edata['firstname'],
            'lastname' => $edata['lastname'],
            'userfullname' => $edata['firstname']." ".$edata['lastname'],
            'emailaddress' => $edata['emailaddress'],
            'emppassword' => md5('1234'),
            'isactive' => '1',
            'modeofentry' => 'Direct',
            'school_id' => $ins
        ); 
        
        $this->db->insert('main_users', $empData); 
        $ins2 = $this->db->insert_id();
        
        $emptabledata = 
                array(  
                    'user_id'=>$ins2,
                    'reporting_manager'=>'',
                    'emp_status_id'=>'1',
                    'businessunit_id'=>$ins1,
                    'department_id'=>'',
                     'school_id' => $ins
        );
        
        $this->db->insert('main_employees', $emptabledata); 
        $ins2 = $this->db->insert_id();
        
        $this->db->close();
        $this->db->initialize(); 
        $this->db->db_select('mss');
        
        return $ins;
    }
    
    public function update_school($dataArray, $id) {
        $this->db->where('school_id', $id);
        $this->db->update('schools', $dataArray);
        return true;
    }
    
    public function get_school_array($school_id = "") {
        $this->db->where(array('status' => '1'));
        if($school_id != ""){
            $this->db->where(array('school_id' => $school_id));
        }
        $this->db->order_by("name", "asc");
        $schools_array = $this->db->get('schools')->result_array(); //echo $this->db->last_query();
        //echo '<pre>'; print_r($schools_array); die;
        return $schools_array;
    }
    
    function get_school_by_name($school_id){
        $rs= "";
        $query= $this->db->get_where('schools', array('school_id' => $school_id));
        if($query)
            $rs = $query->row()->name;
        return $rs;
    } 
    function get_school_report(){
        $rs = array();
        $this->db->select("s.school_id, s.name as school_name, s.telephone, count(DISTINCT(class.class_id)) as total_classes,count(DISTINCT(section.section_id)) as total_sections,count(DISTINCT(student.student_id)) as total_students");
        //$this->db->select("sa.first_name" , "sa.last_name"); 
        $this->db->from("schools as s");
        //$this->db->join("school_admin sa", "sa.school_id=s.school_id","left");
        $this->db->join("class", "class.school_id=s.school_id",'left' );
        $this->db->join("section", "section.school_id=s.school_id",'left');
        $this->db->join("student", "student.school_id=s.school_id",'left');
        $this->db->group_by("s.school_id");
        $query = $this->db->get();
        //echo $this->db->last_query();exit;
        if($query){
            $rs = $query->result_array();
        }
        return $rs;
    }
    
    public function getSingleSchoolData($schoolId) {
        $this->db->where(array('school_id' => $schoolId));
        $schoolArray = $this->db->get('schools')->result_array();
        return $schoolArray[0];
    }
     public function get_school_record($dataArray, $column = "") {
        $return = "";
        if($this->session->userdata['school_id'] > 0){
            $this->db->where('schools.school_id',$this->session->userdata['school_id']);
        }
        $class_record = $this->db->get_where('schools', $dataArray)->row();
       
        if (!empty($column) && !empty($class_record->$column)) {
            $return = $class_record->$column;
        } else {
            $return = $class_record;
        }
        return $return;
     }
      
    
}
