<?php 
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Dynamic_filed_model extends CI_Model {

    private $_table = "dynamic_fields";
    private $_table_dynamic_group = "dynamic_group";
    
    function __construct() {
        parent::__construct();
    }

    function add($dataArr){
        $this->db->insert($this->_table, $dataArr);
        return $this->db->insert_id();
    }
    function get_fields_array() {        
        $return = array();
        $this->db->select("dynamic_fields.*,dynamic_group.name");
        $this->db->from($this->_table);
        $this->db->join($this->_table_dynamic_group,'dynamic_fields.group_id = dynamic_group.id','left');
        return $this->db->get()->result_array();
    }    
     function delete_field($where){
            $this->db->where('id',$where);
            $this->db->delete($this->_table);
    }  
            
    function get_data_by_id($id){
       return $this->db->get_where($this->_table, array('id' => $id))->row();
    }
    function update_field($dataArray, $condition){
        $this->db->where($condition);
        $this->db->update($this->_table, $dataArray);
    } 
    function update_staus($dataArray, $condition){
        $this->db->where($condition);
        $this->db->update($this->_table, $dataArray);
    } 
}