<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Bus_driver_attendence_model extends CI_Model {
    private $_table="bus_driver_attendence"; 
    
    public function __construct() {
        parent::__construct();
    }
      
    function add($dataArr){
        $this->db->insert($this->_table,$dataArr);
        return $this->db->insert_id();
    }
}
