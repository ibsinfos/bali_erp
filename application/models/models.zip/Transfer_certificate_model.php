<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Transfer_certificate_model extends CI_Model {

    private $_table = "transfer_certificate";

    function __construct() {
        parent::__construct();
    }

    public function get_tc_no() {
        $tc_id = $this->db->select('tc_id')->from('transfer_certificate')->order_by('id', 'desc')->get()->row();
        return $tc_id;
    }

    public function save_tc_no($stu_id, $tc_no, $admitted_year, $promoted_class, $promoted_year, $detained_class, $detained_class_year, $observation, $app_certificate, $headmaster_name) {     
        
        $timstamp = date('Y-m-d H:i:s');
               
        $this->db->query("INSERT INTO transfer_certificate (student_id, tc_id, date, addmitted_class_year, promote_class, promote_class_year, detained_class, detained_class_year, observation, certificate_date, headmaster_name,is_approve) VALUES ($stu_id,$tc_no,'" . $timstamp . "','" . $admitted_year . "','" . $promoted_class . "','" . $promoted_year . "','" . $detained_class . "','" . $detained_class_year . "','" . $observation . "','" . $app_certificate . "','" . $headmaster_name . "','1')");
//     echo $this->db->last_query(); die;
        echo $id = $this->db->insert_id();
    }

    public function get_details($student_id) {
        $detail = $this->db->select('*')->from('transfer_certificate')->where('student_id', $student_id)->order_by('id', 'desc')->get()->row();
        return $detail;
    }

    function save_merit_cerificate($student_id, $certificate_for) {
        // echo "for certificate=".$certificate_for; die;
        $timstamp = date('Y-m-d H:i:s');
        $this->db->query("INSERT INTO `merit_certificate` (`merit_id`, `student_id`, `merit_certificate_for`, `date`,`is_approve`) VALUES (NULL, '" . $student_id . "', '" . $certificate_for . "', '" . $timstamp . "','1');");
//     echo $this->db->last_query(); die;
        echo $id = $this->db->insert_id();
    }

    function get_merit_certificate($student_id) {
        $detail = $this->db->select('*')->from('merit_certificate')->where('student_id', $student_id)->order_by('merit_id', 'desc')->get()->row();
        return $detail;
    }

    /**
     * 
     * @param type $id
     * @return type
     */
    function get_data_by_id($id, $returnColsStr = "") {
        if ($returnColsStr == "") {
            return $this->db->get_where($this->_table, array($this->_primary, $id))->result();
        } else {
            return $this->db->select($returnColsStr)->from($this->_table)->where($this->_primary, $id)->get()->result();
        }
    }

    /**
     * 
     * @param type $columnName
     * @param type $conditionArr
     * @param type $return_type="result"
     * @return type
     * example it will use in controlelr
     * 
     * =====bellow is for * data without conditions======
     * get_data_generic_fun('parent','*');
     *  =====bellow is for * data witht conditions======
     * get_data_generic_fun('parent','*',array('column1'=>$column1Value,'column2'=>$column2Value));
     * 
     * =====bellow is for 1 or more column data without conditions======
     * get_data_generic_fun('parent','column1,column2,column3');
     *  =====bellow is for 1 or more column data with conditions======
     * get_data_generic_fun('parent','column1,column2,column3',array('column1'=>$column1Value,'column2'=>$column2Value));
     *  =====bellow is for 1 or more column data with conditions and return as result all======
     * get_data_generic_fun('parent','column1,column2,column3',array('column1'=>$column1Value,'column2'=>$column2Value),'result_arr');
     * 
     * ==== modification for  adding sortby and limit and add conditionArr for AND -- OR -- IN ---
     * get_data_generic_fun('parent','parent_id,passcode',array('passcode'=>$passcoad,'device_token'=>$deviceToken,'condition_type'=>'or'),array('parrent_id'=>'asc','date_time'=>'desc'),1);
     */
    function get_data_by_cols($columnName = "*", $conditionArr = array(), $return_type = "result", $sortByArr = array(), $limit = "") {
        $this->db->select($columnName);
        $condition_type = 'and';
        if (array_key_exists('condition_type', $conditionArr)) {
            if ($conditionArr['condition_type'] != "") {
                $condition_type = $conditionArr['condition_type'];
            }
        }
        unset($conditionArr['condition_type']);
        $condition_in_data_arr = array();
        $startCounter = 0;
        $condition_in_column = "";
        foreach ($conditionArr AS $k => $v) {
            if ($condition_type == 'in') {
                if (array_key_exists('condition_in_data', $conditionArr)) {
                    $condition_in_data_arr = explode(',', $conditionArr['condition_in_data']);
                    $condition_in_column = $conditionArr['condition_in_col'];
                }
            } elseif ($condition_type == 'or') {
                if ($startCounter == 0) {
                    $this->db->where($k, $v);
                } else {
                    $this->db->or_where($k, $v);
                }
            } elseif ($condition_type == 'and') {
                $this->db->where($k, $v);
            }
            $startCounter++;
        }

        if ($condition_type == 'in') {
            if (!empty($condition_in_data_arr))
                $this->db->where_in($condition_in_column, $condition_in_data_arr);
        }

        if ($limit != "") {
            $this->db->limit($limit);
        }

        foreach ($sortByArr AS $key => $val) {
            $this->db->order_by($key, $val);
        }

        if ($return_type == 'result') {
            $rs = $this->db->get($this->_table)->result();
        } else {
            $rs = $this->db->get($this->_table)->result_array();
        }

        return $rs;
    }

}
