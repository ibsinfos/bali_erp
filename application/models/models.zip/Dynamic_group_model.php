<?php 
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Dynamic_group_model extends CI_Model {

    private $_table = "dynamic_group";
 
    function __construct() {
        parent::__construct();
    }

    function add($dataArr){
        $this->db->insert($this->_table, $dataArr);
        return $this->db->insert_id();
    }
    function get_group_array($dataArray = "") {
        $return = array();
        $this->db->select("*");
        $this->db->from($this->_table);
        $this->db->order_by("name", "asc");

        if (!empty($dataArray)) {
            $this->db->where($dataArray);
        }       
        return $this->db->get()->result_array();
    }    
     function delete_group($where){
            $this->db->where('id',$where);
            $this->db->delete($this->_table);
    }  
            
    function get_data_by_id($id){
       return $this->db->get_where($this->_table, array('id' => $id))->row();
    }
    function update_group($dataArray, $condition){
        $this->db->where($condition);
        $this->db->update($this->_table, $dataArray);
    }
    function get_groupname_array(){
        $return = array();
        $this->db->select("id,name");
        $this->db->from($this->_table);
        $this->db->order_by("name", "asc");
         if (!empty($dataArray)) {
            $this->db->where($dataArray);
        }       
        return $this->db->get()->result_array();
    }
}