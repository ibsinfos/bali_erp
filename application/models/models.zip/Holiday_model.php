<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
    
class Holiday_model extends CI_Model {

    private $_table = "holiday";
   

    function __construct() {
        parent::__construct();
    }

    public function save_holiday_list($dataArray) {
        return $this->db->insert("holiday",$dataArray);
 
        }
    function get_holiday_list()
      {
        $running_year=  $this->session->userdata('running_year');
        $first_year=explode("-",$running_year)[0];
        $second_year=explode("-",$running_year)[1];
        $startdate=$first_year."-07-01";
        $enddate=$second_year."-07-01";
        $this->db->order_by("date_start",'ASC');
        return $this->db->get_where("holiday",array("running_year"=>$running_year,"date_start <"=>$enddate,"date_start >"=>$startdate,"is_active"=>"1"))->result_array(); 
       }
      function deactivate_holiday($id)
      {
          $this->db->where('id',$id);
          $this->db->update('holiday',array("is_active"=>"0"));
      }
      function activate_holiday($id)
      {
          $this->db->where('id',$id);
          $this->db->update('holiday',array("is_active"=>"1"));
      }
}

