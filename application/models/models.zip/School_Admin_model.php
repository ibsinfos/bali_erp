    <?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class School_Admin_model extends CI_Model {
    
    public $_hrm_dbname     =   '_hrm';
    public $_fi_dbname     =   '_fi';
    private $_table = "school_admin";
    
    public function __construct() {
        parent::__construct();
    }
    
    function get_instance_name()
    {
        $url_arr=explode('/', $_SERVER['PHP_SELF']);
        $dir=$url_arr[1];
        return $dir;
    }
    
    public function save_admin($data) {
        $emailExist = $this->db->where('email',$data['email'])->get('school_admin')->row();  //pre($emailExist); echo $this->db->last_query(); die;
        if(!empty($emailExist) && $emailExist->school_admin_id>0){
            return 0;
        }
       
       $this->db->insert('school_admin', $data);
       $ins = $this->db->insert_id();
        
        // Save data into HRM main_users table
        
        $hrmData = array(
            'emprole' => 1,
            'userstatus' => 'old',
            'firstname' => $data['first_name'],
            'lastname' => $data['last_name'],
            'userfullname' => $data['first_name']." ".$data['last_name'],
            'emailaddress' => $data['email'],
            'emppassword' => md5($data['original_pass']),
            'contactnumber' => $data['mobile'],
        ); 
        
        $instance = $this->get_instance_name();
        $this->db->db_select($instance.$this->_hrm_dbname);
        $ins1 = $this->db->insert('main_users', $hrmData); 
        $this->db->close();
        $this->db->initialize(); 
        
        // Save data into FI sys_users table
        
        $fiPass = crypt($data['original_pass'],'ib_salt');
        $fiData = array(
            'status' => 'Active',
            'user_type' => 'Admin',
            'fullname' => $data['first_name']." ".$data['last_name'],
            'username' => $data['email'],
            'password' => $fiPass,
            'phonenumber' => $data['mobile'],
        ); 
        
        $this->db->db_select($instance.$this->_fi_dbname);
        $ins1 = $this->db->insert('sys_users', $fiData); 
        $this->db->close();
        $this->db->initialize(); 
        $this->db->db_select('mss');
        
        return $ins;
    }
    
    public function update_admin($dataArray, $id) {
        $emailExist = $this->db->where("email='".$data['email']."' AND school_admin_id!='".$id."'")->get('school_admin')->row();  
        if(!empty($emailExist) && $emailExist->school_admin_id>0){
            return 0;
        }
        $this->db->where('school_admin_id', $id);
        $this->db->update('school_admin', $dataArray);
        return true;
    }
    
    public function update_profile($dataArray, $admin_id){
            $this->db->where('school_admin_id', $admin_id);
            $this->db->update('school_admin', $dataArray);
            return true; 
        }
        
        public function updateadmin_password($dataArray, $admin_id) {
            $this->db->where('school_admin_id', $admin_id);
            $this->db->update('school_admin',$dataArray);
            return true;
        }

    public function get_admin_array() {
        $this->db->where(array('status' => '1'));
        $this->db->order_by("first_name", "asc");
        $admin_array = $this->db->get('school_admin')->result_array();
        return $admin_array;
    }
    
    public function getSingleAdminData($adminId) {
        $this->db->where(array('school_admin_id' => $adminId));
        $adminArray = $this->db->get('school_admin')->result_array();
        return $adminArray[0];
    }
    
    public function get_admin_schools() {
        $this->db->select();
        $this->db->from('admin_school_mapping as mapp');
        $this->db->join( 'schools as sc' , 'sc.school_id = mapp.school_id', 'left' );
        $this->db->join( 'school_admin as sc_admin' , 'sc_admin.school_admin_id = mapp.admin_id', 'left' );

        $this->db->order_by("sc_admin.first_name", "asc");
        $admin_array = $this->db->get()->result_array();
        return $admin_array;
    }
    
    public function assign_school_admin($data) {
        
        $chkExist=$this->db->select()->from('admin_school_mapping')->where("admin_id='".$data['admin_id']."' OR school_id='".$data['school_id']."'")->get()->result_array();

        if(count($chkExist)>0){
            foreach($chkExist as $key=>$mapp) {
                $this->db->where('uid', $mapp['uid']);
                $this->db->delete('admin_school_mapping'); 
            }
        }
        
        $ins = $this->db->insert('admin_school_mapping', $data);
        
        $mailId = $this->db->select()->from('school_admin')->where("school_admin_id='".$data['admin_id']."'")->get()->row();

        $hrmData = array(
            'school_id' => $data['school_id']
        ); 
        
        $instance = $this->get_instance_name();

        $this->db->db_select($instance.$this->_hrm_dbname);
        $this->db->where('emailaddress', $mailId->email);
        $this->db->update("main_users", $hrmData);
        
        $this->db->close();
        $this->db->initialize(); 
        
        $this->db->db_select($instance.$this->_fi_dbname);
        $this->db->where('username', $mailId->email);
        $this->db->update("sys_users", $hrmData);
        
        $this->db->db_select('mss');
        return $ins;
    }
    
     function get_data_by_cols($columnName="*",$conditionArr=array(),$return_type="result",$sortByArr=array(),$limit=""){
        $this->db->select($columnName);
        $condition_type='and';
        if(array_key_exists('condition_type', $conditionArr)){
            if($conditionArr['condition_type']!=""){
                $condition_type=$conditionArr['condition_type'];
            }
        }
        unset($conditionArr['condition_type']);
        $condition_in_data_arr=array();
        $startCounter=0;
        $condition_in_column="";
        foreach($conditionArr AS $k=>$v){
            if($condition_type=='in'){
                if(array_key_exists('condition_in_data', $conditionArr)){
                    $condition_in_data_arr=  explode(',', $conditionArr['condition_in_data']);
                    $condition_in_column=$conditionArr['condition_in_col'];
                }

            }elseif($condition_type=='or'){
                if($startCounter==0){
                    $this->db->where($k,$v);
                }else{
                    $this->db->or_where($k,$v);
                }
            }elseif($condition_type=='and'){
                $this->db->where($k,$v);
            }
            $startCounter++;
        }

         if($condition_type=='in'){
             if(!empty($condition_in_data_arr))
                 $this->db->where_in($condition_in_column,$condition_in_data_arr);
        }

        if($limit!=""){
            $this->db->limit($limit);
        }
        
        if(!empty($sortByArr)) {
            foreach($sortByArr AS $key=>$val){
                $this->db->order_by($key,$val);
            }
        }

        if($return_type=='result'){
            $rs=$this->db->get($this->_table)->result();
        }else{
            $rs=$this->db->get($this->_table)->result_array();
        }

        return $rs;
    }
}
